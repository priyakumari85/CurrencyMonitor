package CurrencyMonitor;

import java.util.*;

public class XMLDocument {
	String Rates;
	ArrayList<Currency> currPairList = new ArrayList<Currency>();
}
