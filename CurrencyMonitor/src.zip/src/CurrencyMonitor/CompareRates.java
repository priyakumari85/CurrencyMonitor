package CurrencyMonitor;

import java.io.IOException;
import java.util.ArrayList;
import java.util.TimerTask;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

public class CompareRates extends TimerTask{
	String _currPair;
	Double _targetval;
	String _url;
	
	CompareRates(String url,String currPair,double targetVal) {
	    this._currPair = currPair;
	    this._targetval = targetVal;
	    this._url = url;
	  }

	public void run() {
		
		Connection conn = new Connection(this._url);
		try {
			//conn.OpenConnection("http://rates.fxcm.com/RatesXML");
			conn.OpenConnection();
		} catch (IOException e) {
			System.out.println("Error connecting to URL");
			e.printStackTrace();
		}
	  
		ReadXML readXml = new ReadXML();
		
		try {
			readXml.CreateCurrPairList();
			CompareAndNotify();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (ParserConfigurationException e) {	
			e.printStackTrace();
		}
	    
	  }
	
	  private void CompareAndNotify(){
		  ArrayList<Currency> currList = ReadXML.xmlDoc.currPairList;		  
		  for(int i=0;i<currList.size();i++){
			  if(currList.get(i).Symbol.equals(this._currPair) && currList.get(i).Bid >= this._targetval){
				  System.out.println("Target Met for " + this._currPair + ":" + this._targetval);
			  }
			  
		  }
	  }

}
