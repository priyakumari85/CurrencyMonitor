package CurrencyMonitor;
import java.net.*;
import java.io.*;

public class Connection {

	String URL;
	public static URLConnection urlConn ;
	
	Connection(String url) {
	    this.URL = url;
	  }

	
	public  void OpenConnection() throws IOException{
		//this.URL = url;
		URL xmlURL;
		try {
			xmlURL = new URL(this.URL);
			urlConn = xmlURL.openConnection();
			urlConn.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.95 Safari/537.11");
			urlConn.connect();
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			System.out.println("Error Connecting to URL");
			e.printStackTrace();
		}

	}

}
