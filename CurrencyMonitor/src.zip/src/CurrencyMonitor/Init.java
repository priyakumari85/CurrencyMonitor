package CurrencyMonitor;

import java.util.Calendar;
import java.util.Scanner;
import java.util.Timer;
import java.util.TimerTask;


public class Init {

	public static void main(String[] args) throws Exception  {
		
		Scanner scanner = new Scanner(System.in);  // input Scanner
		//System.out.println("Enter the Source URL");
		String url = "http://rates.fxcm.com/RatesXML";//scanner.nextLine();
		
		//System.out.println("Enter Currency Pair Symbol");
		String currpair = "EURUSD";//scanner.nextLine();
		
		//System.out.println("Enter Target Value");
		double targetVal = 1.13007;//scanner.nextDouble();
		
		Calendar date = Calendar.getInstance();
		
		Timer timer = new Timer();
		timer.schedule(
			      new CompareRates(url,currpair,targetVal),
				//new CompareRates(),
			      date.getTime(),
			      10000
			    );
		
		
	}

}
