package CurrencyMonitor;

import java.util.Date;

public class Currency {
	String Symbol;
	double Bid;
	double Ask;
	double High;
	double Low;
	int Direction;
	String Last; 

}
