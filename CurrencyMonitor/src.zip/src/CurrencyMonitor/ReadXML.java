package CurrencyMonitor;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import javax.xml.parsers.DocumentBuilder; 
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.DocumentType;
import org.w3c.dom.Element;
import org.w3c.dom.Entity;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class ReadXML {
	
	public static XMLDocument xmlDoc;
	public void CreateCurrPairList() throws IOException, SAXException, ParserConfigurationException{
		System.out.println("Reading Data Started !!");
		try {	
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder(); 
			Document doc = db.parse(Connection.urlConn.getInputStream());
			
			xmlDoc = new XMLDocument();

	        xmlDoc.Rates = doc.getDocumentElement().getNodeName();
	         
	         
	        NodeList nList = doc.getElementsByTagName("Rate");
	         
	         for (int temp = 0; temp < nList.getLength(); temp++) {
	        	Currency curr = new Currency();
	            Node nNode = nList.item(temp);
	                      
	            
	            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
	               Element eElement = (Element) nNode;
	               
	               //System.out.println("Symbol : "  + eElement.getAttribute("Symbol"));
	               curr.Symbol = eElement.getAttribute("Symbol");
	               
	              // System.out.println("Bid : " 	 + eElement.getElementsByTagName("Bid").item(0).getTextContent());
	               curr.Bid = Double.parseDouble(eElement.getElementsByTagName("Bid").item(0).getTextContent());
	               
	               //System.out.println("Ask : " + eElement.getElementsByTagName("Ask").item(0).getTextContent());
	               curr.Ask = Double.parseDouble(eElement.getElementsByTagName("Ask").item(0).getTextContent());
	               
	               //System.out.println("High : " + eElement.getElementsByTagName("High").item(0).getTextContent());
	               curr.High = Double.parseDouble(eElement.getElementsByTagName("High").item(0).getTextContent());
	               
	               //System.out.println("Low: " + eElement.getElementsByTagName("Low").item(0).getTextContent());
	               curr.Low = Double.parseDouble(eElement.getElementsByTagName("Low").item(0).getTextContent());
	               
	               //System.out.println("Direction : " + eElement.getElementsByTagName("Direction").item(0).getTextContent());
	               curr.Direction = Integer.parseInt(eElement.getElementsByTagName("Direction").item(0).getTextContent());
	               
				  //System.out.println("Last : " + eElement.getElementsByTagName("Last").item(0).getTextContent());
				  curr.Last = eElement.getElementsByTagName("Last").item(0).getTextContent();
				  xmlDoc.currPairList.add(curr);
	            }
 
	         }
	         System.out.println("Reading Data Finished !!");
	      } catch (Exception e) {
	         e.printStackTrace();
	      }
	            

//		BufferedReader in = new BufferedReader(new InputStreamReader(
//        		Connection.urlConn.getInputStream()));
//        String inputLine;
//        while ((inputLine = in.readLine()) != null) 
//            System.out.println(inputLine);
//        in.close();
        //https://docs.oracle.com/javase/tutorial/jaxp/dom/readingXML.html
	}
}
